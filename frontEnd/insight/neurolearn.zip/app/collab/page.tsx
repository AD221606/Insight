"use client"

export default function CollaborationPage() {
  return (
    <main className="mx-auto max-w-3xl px-4 py-16 md:px-8">
      <div className="relative overflow-hidden rounded-2xl border border-primary/30 bg-background/40 p-10 text-center backdrop-blur">
        <h1 className="text-2xl font-semibold">Peer Collaboration</h1>
        <p className="mt-2 text-muted-foreground">Coming Soon — Real-time chat, groups, and video calls.</p>
        <div
          aria-hidden
          className="pointer-events-none absolute -inset-1 -z-10 animate-pulse rounded-2xl"
          style={{
            boxShadow:
              "inset 0 0 40px 2px color(display-p3 0.00 0.85 0.95 / 0.15), 0 0 60px 10px color(display-p3 0.00 0.85 0.95 / 0.15)",
          }}
        />
      </div>
    </main>
  )
}
