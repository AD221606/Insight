"use client"

export default function PathPage() {
  return (
    <main className="mx-auto max-w-3xl px-4 py-8 md:px-8">
      <h1 className="text-2xl font-semibold">Learning Path Generator</h1>
      <p className="mt-1 text-muted-foreground">Describe your goal, we’ll generate a path you can edit.</p>

      <div className="mt-6 rounded-xl border border-primary/30 bg-background/40 p-4 backdrop-blur">
        <label htmlFor="path-input" className="text-sm">
          What do you want to learn?
        </label>
        <input
          id="path-input"
          placeholder="e.g., Machine Learning Basics"
          className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2 outline-none ring-0 transition-shadow focus:border-primary focus:shadow-[0_0_0_3px] focus:shadow-primary/20"
        />
      </div>
    </main>
  )
}
