"use client"

export default function NotesPage() {
  return (
    <main className="mx-auto max-w-3xl px-4 py-8 md:px-8">
      <h1 className="text-2xl font-semibold">Notes Summariser & Maker</h1>
      <p className="mt-1 text-muted-foreground">Upload your notes to get structured summaries and chat within them.</p>

      <div
        role="button"
        tabIndex={0}
        className="mt-6 flex h-40 items-center justify-center rounded-xl border border-dashed border-primary/30 bg-background/40 text-muted-foreground backdrop-blur outline-none transition-all hover:border-primary hover:text-foreground hover:shadow-[0_0_16px_2px] hover:shadow-primary/15 focus-visible:border-primary"
      >
        Drag & Drop Notes
      </div>
    </main>
  )
}
