"use client"

import { Button } from "@/components/ui/button"

export default function YouTubeRecommenderPage() {
  return (
    <main className="mx-auto max-w-3xl px-4 py-8 md:px-8">
      <h1 className="text-2xl font-semibold">AI-Powered YouTube Recommender</h1>
      <p className="mt-1 text-muted-foreground">
        Paste a topic or demand, then fine-tune by interests, level, and time.
      </p>

      <div className="mt-6 rounded-xl border border-primary/30 bg-background/40 p-4 backdrop-blur">
        <label htmlFor="yt-input" className="text-sm">
          What do you want to learn?
        </label>
        <input
          id="yt-input"
          placeholder="e.g., Linear Algebra for ML"
          className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2 outline-none ring-0 transition-shadow focus:border-primary focus:shadow-[0_0_0_3px] focus:shadow-primary/20"
        />
        <div className="mt-3 flex gap-2">
          <Button className="border-primary/40 hover:border-primary hover:shadow-[0_0_16px_2px] hover:shadow-primary/25">
            Generate
          </Button>
          <Button variant="outline">Advanced Filters</Button>
        </div>
      </div>
    </main>
  )
}
