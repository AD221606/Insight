"use client"

export default function TechniquesPage() {
  return (
    <main className="mx-auto max-w-3xl px-4 py-8 md:px-8">
      <h1 className="text-2xl font-semibold">Techniques & Timers</h1>
      <p className="mt-1 text-muted-foreground">Focus better with proven study methods and timers.</p>

      <div className="mt-6 grid grid-cols-2 gap-3">
        {["Pomodoro", "52/17", "Flowtime", "Eisenhower", "Spaced Repetition","Flash Cards"].map((t) => (
          <div
            key={t}
            className="rounded-lg border border-primary/30 bg-background/40 p-3 text-center transition-all hover:border-primary hover:shadow-[0_0_16px_2px] hover:shadow-primary/15"
          >
            {t}
          </div>
        ))}
      </div>
    </main>
  )
}
