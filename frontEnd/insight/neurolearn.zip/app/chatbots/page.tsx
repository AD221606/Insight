"use client"

export default function ChatbotsPage() {
  return (
    <main className="mx-auto max-w-3xl px-4 py-8 md:px-8">
      <h1 className="text-2xl font-semibold">Subject-Specific Chatbots</h1>
      <p className="mt-1 text-muted-foreground">Pick a subject to start chatting or try the general assistant.</p>

      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
        {["General", "Math", "Physics", "Chemistry", "CS", "Social Science"].map((s) => (
          <div
            key={s}
            className="rounded-lg border border-primary/30 bg-background/40 p-3 text-center transition-all hover:border-primary hover:shadow-[0_0_16px_2px] hover:shadow-primary/15"
          >
            {s}
          </div>
        ))}
      </div>
    </main>
  )
}
