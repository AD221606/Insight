"use client"
import { useEffect, useState } from "react"
import { cn } from "@/lib/utils"
import { ThemeToggle } from "@/components/theme-toggle"
import { BackgroundFX } from "@/components/background-fx"
import { Hero } from "@/components/hero"
import { ProgressRing } from "@/components/progress-ring"
import { NavGrid } from "@/components/nav-grid"

export default function HomePage() {
  // Example synced progress state (placeholder until connected to Learning Path)
  const [progress, setProgress] = useState(42)

  // Smooth page enter animation (fade-slide)
  const [mounted, setMounted] = useState(false)
  useEffect(() => {
    const t = requestAnimationFrame(() => setMounted(true))
    return () => cancelAnimationFrame(t)
  }, [])

  // Demo: Animate progress ring on load for delight
  useEffect(() => {
    let raf: number
    let current = 0
    const animate = () => {
      current += (progress - current) * 0.06
      if (Math.abs(current - progress) > 0.5) {
        setProgress(Math.round(current))
        raf = requestAnimationFrame(animate)
      } else {
        setProgress(progress)
      }
    }
    raf = requestAnimationFrame(animate)
    return () => cancelAnimationFrame(raf)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <main
      className={cn(
        "relative min-h-dvh overflow-hidden",
        mounted ? "opacity-100 translate-y-0 transition-all duration-500" : "opacity-0 translate-y-2",
      )}
      aria-label="NeuroLearn Home"
    >
      {/* Background VFX */}
      <BackgroundFX />

      {/* Top bar: brand + theme toggle */}
      <header className="relative z-10 flex items-center justify-between px-4 py-4 md:px-8">
        <div className="flex items-center gap-2">
          <div
            aria-hidden
            className="size-3 rounded-full"
            style={{
              boxShadow:
                "0 0 12px 2px color(display-p3 0.0 0.85 0.95 / 0.65), 0 0 30px 6px color(display-p3 0.0 0.85 0.95 / 0.25)",
              background: "oklch(0.77 0.188 195)", // neon cyan accent as a solid dot
            }}
          />
          <p className="font-semibold tracking-tight">NeuroLearn</p>
        </div>
        <ThemeToggle />
      </header>

      {/* Hero + Progress */}
      <section className="relative z-10 mx-auto mt-6 flex max-w-6xl flex-col gap-8 px-4 md:mt-10 md:px-8">
        <div className="flex flex-col items-center gap-6 text-center">
          <Hero />
          <div className="flex items-center gap-6">
            <ProgressRing value={progress} size={92} strokeWidth={8} />
            <div className="text-left">
              <p className="text-sm text-muted-foreground">Learning Progress</p>
              <p className="text-3xl font-semibold">{progress}%</p>
            </div>
          </div>
        </div>
      </section>

      {/* Navigation grid */}
      <section className="relative z-10 mx-auto mt-10 max-w-6xl px-4 md:px-8">
        <NavGrid
          items={[
            {
              href: "/youtube",
              title: "AI YouTube Recommender",
              desc: "Personalized playlists by topic, level, and time.",
              icon: "▶",
            },
            {
              href: "/chatbots",
              title: "Subject Chatbots",
              desc: "Ask Math, Physics, Chem, and more with context.",
              icon: "💬",
            },
            {
              href: "/path",
              title: "Learning Path",
              desc: "Auto-generate, edit, and track milestones.",
              icon: "🗺",
            },
            {
              href: "/notes",
              title: "Notes Summariser",
              desc: "Upload notes, get clean summaries, chat with them.",
              icon: "📝",
            },
            {
              href: "/techniques",
              title: "Techniques & Timers",
              desc: "Pomodoro, Flowtime, Eisenhower, and more.",
              icon: "⏱",
            },
            {
              href: "/collab",
              title: "Peer Collaboration",
              desc: "Coming soon: study groups and live sessions.",
              icon: "👥",
            },
          ]}
        />
      </section>

      {/* Footer */}
      <footer className="relative z-10 mx-auto mt-14 max-w-6xl px-4 pb-10 text-center text-sm text-muted-foreground md:px-8">
        <p>© {new Date().getFullYear()} NeuroLearn. Learn Smarter, Not Harder.</p>
      </footer>
    </main>
  )
}
