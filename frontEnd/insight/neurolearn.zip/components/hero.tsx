"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export function Hero() {
  const [visible, setVisible] = useState(false)
  useEffect(() => {
    const t = requestAnimationFrame(() => setVisible(true))
    return () => cancelAnimationFrame(t)
  }, [])

  return (
    <div className="relative flex flex-col items-center gap-4">
      <h1
        className={[
          "text-balance text-3xl font-semibold leading-tight sm:text-4xl md:text-5xl",
          visible ? "opacity-100 translate-y-0 transition-all duration-700" : "opacity-0 translate-y-2",
        ].join(" ")}
      >
        Learn Smarter, Not Harder
      </h1>
      <p
        className={[
          "text-pretty max-w-2xl text-sm text-muted-foreground sm:text-base",
          visible ? "opacity-100 translate-y-0 transition-all delay-100 duration-700" : "opacity-0 translate-y-2",
        ].join(" ")}
      >
        Personalized recommendations, dynamic learning paths, smart notes, and focused study techniques—all in one
        place.
      </p>
      <div
        className={[
          "flex items-center gap-3",
          visible ? "opacity-100 translate-y-0 transition-all delay-200 duration-700" : "opacity-0 translate-y-2",
        ].join(" ")}
      >
        <Link href="/youtube" prefetch>
          <Button
            variant="outline"
            className="border-primary/40 hover:border-primary hover:shadow-[0_0_16px_2px] hover:shadow-primary/25 bg-transparent"
          >
            Try the Recommender
          </Button>
        </Link>
      </div>
    </div>
  )
}
