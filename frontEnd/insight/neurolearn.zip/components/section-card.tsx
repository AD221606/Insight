"use client"

import Link from "next/link"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"

type SectionCardProps = {
  href: string
  icon?: string
  title: string
  desc: string
}

export function SectionCard({ href, icon, title, desc }: SectionCardProps) {
  return (
    <Link href={href} prefetch>
      <Card
        className={cn(
          "group relative h-full overflow-hidden rounded-xl border border-primary/30 bg-background/40 p-4 backdrop-blur",
          "transition-all duration-300 hover:border-primary hover:bg-background/60",
          "hover:shadow-[0_0_30px_4px] hover:shadow-primary/15",
        )}
      >
        {/* subtle reactive background */}
        <div
          aria-hidden
          className="pointer-events-none absolute -inset-1 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
          style={{
            background:
              "radial-gradient(120px 120px at var(--mx,50%) var(--my,50%), color(display-p3 0.00 0.85 0.95 / 0.22), transparent 60%)",
          }}
        />
        <div
          className="relative flex h-full flex-col gap-2"
          onMouseMove={(e) => {
            const el = e.currentTarget.parentElement as HTMLElement
            if (!el) return
            const rect = el.getBoundingClientRect()
            el.style.setProperty("--mx", `${((e.clientX - rect.left) / rect.width) * 100}%`)
            el.style.setProperty("--my", `${((e.clientY - rect.top) / rect.height) * 100}%`)
          }}
        >
          <div className="flex items-center gap-2">
            <div className="text-xl">{icon}</div>
            <h3 className="text-base font-semibold md:text-lg">{title}</h3>
          </div>
          <p className="text-sm text-muted-foreground">{desc}</p>
          <div className="mt-auto flex items-center gap-1 pt-2 text-sm text-primary">
            Explore <span aria-hidden>→</span>
          </div>
        </div>
      </Card>
    </Link>
  )
}
