"use client"

import { useMemo } from "react"
import { cn } from "@/lib/utils"

type Props = {
  value: number // 0-100
  size?: number
  strokeWidth?: number
  className?: string
}

export function ProgressRing({ value, size = 80, strokeWidth = 8, className }: Props) {
  const radius = (size - strokeWidth) / 2
  const circumference = 2 * Math.PI * radius
  const offset = useMemo(() => {
    const v = Math.min(100, Math.max(0, value))
    return circumference - (v / 100) * circumference
  }, [value, circumference])

  return (
    <div
      className={cn("relative", className)}
      style={{
        width: size,
        height: size,
        filter: "drop-shadow(0 0 10px color(display-p3 0.00 0.85 0.95 / 0.35))",
      }}
      aria-label={`Progress ${value}%`}
    >
      <svg width={size} height={size} role="img" aria-hidden="true">
        <circle cx={size / 2} cy={size / 2} r={radius} stroke="oklch(0.92 0 0)" strokeWidth={strokeWidth} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="oklch(0.77 0.188 195)"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 600ms ease" }}
        />
      </svg>
      <div className="pointer-events-none absolute inset-0 grid place-items-center text-xs font-medium">
        {Math.round(value)}%
      </div>
    </div>
  )
}
