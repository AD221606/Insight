"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

export function ThemeToggle() {
  const [mounted, setMounted] = useState(false)
  const [isDark, setIsDark] = useState(false)

  useEffect(() => {
    setMounted(true)
    const saved = typeof window !== "undefined" ? localStorage.getItem("theme") : null
    const prefersDark =
      typeof window !== "undefined" && window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches
    const initialDark = saved ? saved === "dark" : prefersDark
    setIsDark(initialDark)
    if (initialDark) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [])

  const toggle = () => {
    const next = !isDark
    setIsDark(next)
    if (next) {
      document.documentElement.classList.add("dark")
      localStorage.setItem("theme", "dark")
    } else {
      document.documentElement.classList.remove("dark")
      localStorage.setItem("theme", "light")
    }
  }

  if (!mounted) return null

  return (
    <Button
      variant="outline"
      size="sm"
      onClick={toggle}
      className={cn(
        "relative overflow-hidden",
        "transition-all duration-300",
        "border-primary/40 hover:border-primary",
        // Glow ring on hover
        "hover:shadow-[0_0_16px_2px] hover:shadow-primary/35",
      )}
      aria-label="Toggle theme"
    >
      <span className="sr-only">Toggle theme</span>
      <span className="inline-block w-4 text-center">{isDark ? "🌙" : "☀️"}</span>
    </Button>
  )
}
