"use client"

import { useEffect, useRef } from "react"
import { cn } from "@/lib/utils"

export function BackgroundFX() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const rafRef = useRef<number | null>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d", { alpha: true })
    if (!ctx) return

    let width = (canvas.width = canvas.offsetWidth * devicePixelRatio)
    let height = (canvas.height = canvas.offsetHeight * devicePixelRatio)

    const onResize = () => {
      width = canvas.width = canvas.offsetWidth * devicePixelRatio
      height = canvas.height = canvas.offsetHeight * devicePixelRatio
    }
    const ro = new ResizeObserver(onResize)
    ro.observe(canvas)

    // Particle setup
    const count = 36
    const particles = Array.from({ length: count }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.25 * devicePixelRatio,
      vy: (Math.random() - 0.5) * 0.25 * devicePixelRatio,
      r: (2 + Math.random() * 2) * devicePixelRatio,
    }))

    const draw = () => {
      ctx.clearRect(0, 0, width, height)

      // gradient waves (soft overlay)
      const g1 = ctx.createLinearGradient(0, 0, width, height)
      // Using tokens via approximated hues for neon cyan/blue/pink accents in dark; subtle in light
      g1.addColorStop(0, "rgba(56, 189, 248, 0.06)") // cyan-400
      g1.addColorStop(1, "rgba(147, 51, 234, 0.04)") // purple-600 (very subtle wash)
      ctx.fillStyle = g1
      ctx.fillRect(0, 0, width, height)

      // particles
      ctx.globalCompositeOperation = "lighter"
      for (const p of particles) {
        p.x += p.vx
        p.y += p.vy
        if (p.x < 0 || p.x > width) p.vx *= -1
        if (p.y < 0 || p.y > height) p.vy *= -1

        const grd = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 5)
        grd.addColorStop(0, "rgba(56,189,248,0.35)")
        grd.addColorStop(1, "rgba(56,189,248,0)")
        ctx.fillStyle = grd
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.r * 2, 0, Math.PI * 2)
        ctx.fill()
      }
      ctx.globalCompositeOperation = "source-over"

      rafRef.current = requestAnimationFrame(draw)
    }
    rafRef.current = requestAnimationFrame(draw)

    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
      ro.disconnect()
    }
  }, [])

  return (
    <div className="pointer-events-none absolute inset-0">
      <canvas ref={canvasRef} className={cn("h-full w-full")} aria-hidden />
      {/* subtle overlay to increase contrast in light mode */}
      <div
        className="absolute inset-0 bg-gradient-to-b from-transparent via-background/20 to-background/40"
        aria-hidden
      />
    </div>
  )
}
